<div class="preloader flex-column justify-content-center align-items-center bg-dark">
    <img class="animation__shake" src="<?php echo base_url('assets') ?>/img/logo_kejaksaan.png" alt="AdminLTELogo" height="250" width="250">
</div>