<?= $this->extend("admin/layouts/index") ?>

<?= $this->section("title") ?>Berita<?= $this->endSection() ?>

<?= $this->section("content") ?>
<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive p-0">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th style="width: 10px">No</th>
                                <th>Judul</th>
                                <th>Tanggal</th>
                                <th>Isi</th>
                                <th>Gambar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($beritas as $key => $berita): ?>
                            <tr>
                                <td><?= $key+1 ?>.</td>
                                <td><?= $berita['judul'] ?></td>
                                <td>
                                    <?php
                                    $date=date_create($berita['tanggal']);
                                    echo date_format($date,"d M Y");
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    $content = $berita['isi'];
                                    $max_chars = 300;
                                    if (strlen($content) > $max_chars) {
                                        $content = substr($content, 0, $max_chars) . '...';
                                    }
                                    echo esc($content) 
                                    ?>
                                </td>
                                <td><img src="<?php echo base_url('assets/img/berita/' . $berita['gambar']) ?>" alt="" width="100%"></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer clearfix">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                    </ul>
                </div>
                <!-- /.card-body -->
            </div>
        <div class="col-12">
    </div>
</section>
<?= $this->endSection() ?>
