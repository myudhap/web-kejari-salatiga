<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddNameRoleColumnUserTable extends Migration
{
    public function up()
    {
        $this->forge->addColumn('users', [
            "name" => [
                "type" => "VARCHAR",
                "constraint" => 255,
                "null" => FALSE
            ],
            "role" => [
                "type" => "ENUM",
                "constraint" => ["admin", "pidum", "pidsus", "intel", "bin", "datun", "bb", "visitor"],
                "null" => FALSE
            ]
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn("users", ["name", "role"]);
    }
}
