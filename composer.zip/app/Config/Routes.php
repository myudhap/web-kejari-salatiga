<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var ViewRouteCollection $routes
 */
$routes->get('/', 'HomeController::index');

$routes->get('/profil/sejarah', 'ProfileController::sejarah');
$routes->get('/profil/visi-misi', 'ProfileController::visiMisi');
$routes->get('/profil/logo', 'ProfileController::logo');
$routes->get('/profil/tri-krama-adhyaksa', 'ProfileController::triKrama');
$routes->get('/profil/struktur-organisasi', 'ProfileController::strukturOrganisasi');

$routes->get('/bidang/pembinaan', 'BidangController::pembinaan');
$routes->get('/bidang/intel', 'BidangController::intel');
$routes->get('/bidang/pidum', 'BidangController::pidum');
$routes->get('/bidang/pidsus', 'BidangController::pidsus');
$routes->get('/bidang/datun', 'BidangController::datun');
$routes->get('/bidang/pb3r', 'BidangController::pb3r');

$routes->get('/layanan/survey', 'LayananController::survey');
$routes->get('/layanan/barang-bukti', 'LayananController::barangBukti', ['as' => 'layanan.barang_bukti']);
$routes->get('/layanan/pelayanan-hukum-gratis', 'LayananController::pelayananHukumGratis');
$routes->get('/layanan/kunjungan-tahanan', 'LayananController::kunjunganTahanan');

$routes->get('/berita', 'BeritaController::index');

$routes->get('/informasi/jadwal-sidang', 'InformasiController::jadwalSidang');

$routes->group('panel', static function($routes) {
    $routes->get('/', 'Admin\DashboardController::index');
    $routes->get('berita', 'Admin\BeritaController::index');
    $routes->get('layanan/barang-bukti', 'Admin\LayananController::barangBukti');
});

$routes->post('/layanan/barang-bukti', 'BarangBuktiController::storePengambilanBarangBukti');
$routes->post('/layanan/barang-bukti/check', 'BarangBuktiController::checkPengambilanBarangBukti');

service('auth')->routes($routes);
