<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class LayananController extends BaseController
{
    protected $data;

    public function __construct()
    {
        $this->data = [
            "base" => "Layanan"
        ];
    }

    public function survey()
    {
        return view('main/layanan/surveyView', $this->data);
    }

    public function barangBukti()
    {
        return view('main/layanan/barangBuktiView', $this->data);
    }

    public function pelayananHukumGratis()
    {
        return view('main/layanan/pelayananHukumGratis', $this->data);
    }

    public function kunjunganTahanan()
    {
        return view('main/layanan/kunjunganTahanan', $this->data);
    }
}
