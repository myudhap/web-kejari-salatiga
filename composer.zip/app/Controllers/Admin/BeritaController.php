<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\BeritaModel;

class BeritaController extends BaseController
{
    protected $data;
    protected $model;

    public function __construct()
    {
        $this->data = [
            "title" => "Berita"
        ];
        $this->model = new BeritaModel();
    }

    public function index()
    {
        $this->data['beritas'] = $this->model->findAll();

        return view('admin/BeritaView', $this->data);
    }
}
