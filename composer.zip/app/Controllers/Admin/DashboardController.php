<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\BeritaModel;

class DashboardController extends BaseController
{
    protected $data;

    public function __construct()
    {
        $this->data = [
            "title" => "Dashboard"
        ];
    }

    public function index()
    {
        // $userModel = new CustomUserModel();
        $beritaModel = new BeritaModel();

        // $this->data['users'] = $userModel->findAll();
        $this->data['users'] = [1,2,3,4];
        $this->data['berita'] = $beritaModel->findAll();

        return view('admin/DashboardView', $this->data);
    }
}
